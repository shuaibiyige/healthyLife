/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author lice
 */
@Entity
@Table(name = "USERS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Users.findAll", query = "SELECT u FROM Users u")
    , @NamedQuery(name = "Users.findByUserId", query = "SELECT u FROM Users u WHERE u.userId = :userId")
    , @NamedQuery(name = "Users.findByUserFirstname", query = "SELECT u FROM Users u WHERE u.userFirstname = :userFirstname")
    , @NamedQuery(name = "Users.findByUserSurname", query = "SELECT u FROM Users u WHERE u.userSurname = :userSurname")
    , @NamedQuery(name = "Users.findByUserEmail", query = "SELECT u FROM Users u WHERE u.userEmail = :userEmail")
    , @NamedQuery(name = "Users.findByUserDob", query = "SELECT u FROM Users u WHERE u.userDob = :userDob")
    , @NamedQuery(name = "Users.findByUserHeight", query = "SELECT u FROM Users u WHERE u.userHeight = :userHeight")
    , @NamedQuery(name = "Users.findByUserWeight", query = "SELECT u FROM Users u WHERE u.userWeight = :userWeight")
    , @NamedQuery(name = "Users.findByUserGender", query = "SELECT u FROM Users u WHERE u.userGender = :userGender")
    , @NamedQuery(name = "Users.findByUserAddress", query = "SELECT u FROM Users u WHERE u.userAddress = :userAddress")
    , @NamedQuery(name = "Users.findByUserPostcode", query = "SELECT u FROM Users u WHERE u.userPostcode = :userPostcode")
    , @NamedQuery(name = "Users.findByLevelOfActivity", query = "SELECT u FROM Users u WHERE u.levelOfActivity = :levelOfActivity")
    , @NamedQuery(name = "Users.findByStepsPerMile", query = "SELECT u FROM Users u WHERE u.stepsPerMile = :stepsPerMile")
    , @NamedQuery(name = "Users.findByEmailAndUserName2", query = "SELECT u FROM Users u WHERE u.credentials.userName = :userName AND u.userEmail = :userEmail")})
public class Users implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "USER_ID")
    private Integer userId;
    @Size(max = 10)
    @Column(name = "USER_FIRSTNAME")
    private String userFirstname;
    @Size(max = 10)
    @Column(name = "USER_SURNAME")
    private String userSurname;
    @Size(max = 50)
    @Column(name = "USER_EMAIL")
    private String userEmail;
    @Column(name = "USER_DOB")
    @Temporal(TemporalType.DATE)
    private Date userDob;
    @Column(name = "USER_HEIGHT")
    private Double userHeight;
    @Column(name = "USER_WEIGHT")
    private Double userWeight;
    @Size(max = 1)
    @Column(name = "USER_GENDER")
    private String userGender;
    @Size(max = 50)
    @Column(name = "USER_ADDRESS")
    private String userAddress;
    @Column(name = "USER_POSTCODE")
    private Integer userPostcode;
    @Column(name = "LEVEL_OF_ACTIVITY")
    private Integer levelOfActivity;
    @Column(name = "STEPS_PER_MILE")
    private Double stepsPerMile;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "users")
    private Credentials credentials;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "users")
    private Collection<Consumptions> consumptionsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "users")
    private Collection<Reports> reportsCollection;

    public Users() {
    }

    public Users(Integer userId) {
        this.userId = userId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserFirstname() {
        return userFirstname;
    }

    public void setUserFirstname(String userFirstname) {
        this.userFirstname = userFirstname;
    }

    public String getUserSurname() {
        return userSurname;
    }

    public void setUserSurname(String userSurname) {
        this.userSurname = userSurname;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Date getUserDob() {
        return userDob;
    }

    public void setUserDob(Date userDob) {
        this.userDob = userDob;
    }

    public Double getUserHeight() {
        return userHeight;
    }

    public void setUserHeight(Double userHeight) {
        this.userHeight = userHeight;
    }

    public Double getUserWeight() {
        return userWeight;
    }

    public void setUserWeight(Double userWeight) {
        this.userWeight = userWeight;
    }

    public String getUserGender() {
        return userGender;
    }

    public void setUserGender(String userGender) {
        this.userGender = userGender;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public Integer getUserPostcode() {
        return userPostcode;
    }

    public void setUserPostcode(Integer userPostcode) {
        this.userPostcode = userPostcode;
    }

    public Integer getLevelOfActivity() {
        return levelOfActivity;
    }

    public void setLevelOfActivity(Integer levelOfActivity) {
        this.levelOfActivity = levelOfActivity;
    }

    public Double getStepsPerMile() {
        return stepsPerMile;
    }

    public void setStepsPerMile(Double stepsPerMile) {
        this.stepsPerMile = stepsPerMile;
    }

    @XmlTransient
    public Credentials getCredentials() {
        return credentials;
    }

    public void setCredentials(Credentials credentials) {
        this.credentials = credentials;
    }

    @XmlTransient
    public Collection<Consumptions> getConsumptionsCollection() {
        return consumptionsCollection;
    }

    public void setConsumptionsCollection(Collection<Consumptions> consumptionsCollection) {
        this.consumptionsCollection = consumptionsCollection;
    }

    @XmlTransient
    public Collection<Reports> getReportsCollection() {
        return reportsCollection;
    }

    public void setReportsCollection(Collection<Reports> reportsCollection) {
        this.reportsCollection = reportsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userId != null ? userId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Users)) {
            return false;
        }
        Users other = (Users) object;
        if ((this.userId == null && other.userId != null) || (this.userId != null && !this.userId.equals(other.userId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Assignment1.Users[ userId=" + userId + " ]";
    }
    
}
