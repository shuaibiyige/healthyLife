/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author lice
 */
@Entity
@Table(name = "FOODS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Foods.findAll", query = "SELECT f FROM Foods f")
    , @NamedQuery(name = "Foods.findByFoodId", query = "SELECT f FROM Foods f WHERE f.foodId = :foodId")
    , @NamedQuery(name = "Foods.findByFoodName", query = "SELECT f FROM Foods f WHERE f.foodName = :foodName")
    , @NamedQuery(name = "Foods.findByFoodCategory", query = "SELECT f FROM Foods f WHERE f.foodCategory = :foodCategory")
    , @NamedQuery(name = "Foods.findByCalorie", query = "SELECT f FROM Foods f WHERE f.calorie = :calorie")
    , @NamedQuery(name = "Foods.findByServingUnit", query = "SELECT f FROM Foods f WHERE f.servingUnit = :servingUnit")
    , @NamedQuery(name = "Foods.findByServingAmount", query = "SELECT f FROM Foods f WHERE f.servingAmount = :servingAmount")
    , @NamedQuery(name = "Foods.findByFat", query = "SELECT f FROM Foods f WHERE f.fat = :fat")})
public class Foods implements Serializable {

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "SERVING_AMOUNT")
    private BigDecimal servingAmount;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "FOOD_ID")
    private Integer foodId;
    @Size(max = 50)
    @Column(name = "FOOD_NAME")
    private String foodName;
    @Size(max = 20)
    @Column(name = "FOOD_CATEGORY")
    private String foodCategory;
    @Column(name = "CALORIE")
    private Integer calorie;
    @Size(max = 20)
    @Column(name = "SERVING_UNIT")
    private String servingUnit;
    @Column(name = "FAT")
    private Integer fat;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "foods")
    private Collection<Consumptions> consumptionsCollection;

    public Foods() {
    }

    public Foods(Integer foodId) {
        this.foodId = foodId;
    }

    public Integer getFoodId() {
        return foodId;
    }

    public void setFoodId(Integer foodId) {
        this.foodId = foodId;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodCategory() {
        return foodCategory;
    }

    public void setFoodCategory(String foodCategory) {
        this.foodCategory = foodCategory;
    }

    public Integer getCalorie() {
        return calorie;
    }

    public void setCalorie(Integer calorie) {
        this.calorie = calorie;
    }

    public String getServingUnit() {
        return servingUnit;
    }

    public void setServingUnit(String servingUnit) {
        this.servingUnit = servingUnit;
    }

    public BigDecimal getServingAmount() {
        return servingAmount;
    }

    public void setServingAmount(BigDecimal servingAmount) {
        this.servingAmount = servingAmount;
    }

    public Integer getFat() {
        return fat;
    }

    public void setFat(Integer fat) {
        this.fat = fat;
    }

    @XmlTransient
    public Collection<Consumptions> getConsumptionsCollection() {
        return consumptionsCollection;
    }

    public void setConsumptionsCollection(Collection<Consumptions> consumptionsCollection) {
        this.consumptionsCollection = consumptionsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (foodId != null ? foodId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Foods)) {
            return false;
        }
        Foods other = (Foods) object;
        if ((this.foodId == null && other.foodId != null) || (this.foodId != null && !this.foodId.equals(other.foodId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Assignment1.Foods[ foodId=" + foodId + " ]";
    }
    
}
