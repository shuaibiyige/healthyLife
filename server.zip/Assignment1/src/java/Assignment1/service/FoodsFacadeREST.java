/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1.service;

import Assignment1.Foods;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author lice
 */
@Stateless
@Path("assignment1.foods")
public class FoodsFacadeREST extends AbstractFacade<Foods> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    public FoodsFacadeREST() {
        super(Foods.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Foods entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Foods entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Foods find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.APPLICATION_JSON)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findByFoodName/{foodName}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findByFoodName(@PathParam("foodName") String foodName) {
        Query query = em.createNamedQuery("Foods.findByFoodName");
        query.setParameter("foodName", foodName);
        return query.getResultList();
    }
    
    @GET
    @Path("findByFoodCategory/{foodCategory}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findByFoodCategory(@PathParam("foodCategory") String foodCategory) {
        Query query = em.createNamedQuery("Foods.findByFoodCategory");
        query.setParameter("foodCategory", foodCategory);
        return query.getResultList();
    }
    
    @GET
    @Path("findByCalorie/{calorie}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findByCalorie(@PathParam("calorie") Double calorie) {
        Query query = em.createNamedQuery("Foods.findByCalorie");
        query.setParameter("calorie", calorie);
        return query.getResultList();
    }
    
    @GET
    @Path("findByServingUnit/{servingUnit}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findByServingUnit(@PathParam("servingUnit") String servingUnit) {
        Query query = em.createNamedQuery("Foods.findByServingUnit");
        query.setParameter("servingUnit", servingUnit);
        return query.getResultList();
    }
    
    @GET
    @Path("findByServingAmount/{servingAmount}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findByServingAmount(@PathParam("servingAmount") BigDecimal servingAmount) {
        Query query = em.createNamedQuery("Foods.findByServingAmount");
        query.setParameter("servingAmount", servingAmount);
        return query.getResultList();
    }
    
    @GET
    @Path("findByFat/{fat}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findByFat(@PathParam("fat") Double fat) {
        Query query = em.createNamedQuery("Foods.findByFat");
        query.setParameter("fat", fat);
        return query.getResultList();
    }
    
    @GET
    @Path("findFoodNameAndCalorie/{foodName}/{calorie}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findFoodNameAndCalorie(@PathParam("foodName") String foodName, @PathParam("calorie") Double calorie) {
        TypedQuery<Foods> query = em.createQuery("SELECT f FROM Foods f WHERE f.foodName = :foodName AND f.calorie = :calorie", Foods.class);
        query.setParameter("foodName", foodName);
        query.setParameter("calorie", calorie);
        return query.getResultList();
    }
    
    @GET
    @Path("findFoodCategory")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Foods> findFoodCategory()
    {
        List<Foods> list = new ArrayList<>();
        List<Foods> food = findAll();
        List<Foods> unique = food.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(Comparator.comparing(Foods::getFoodCategory))), ArrayList::new));
        return unique;
    }
    
    @GET
    @Path("findIdByFoodName/{foodName}")
    @Produces(MediaType.APPLICATION_JSON)
    public String findIdByFoodName(@PathParam("foodName") String foodName)
    {
        TypedQuery<Foods> query = em.createQuery("SELECT f FROM Foods f WHERE f.foodName = :foodName", Foods.class);
        query.setParameter("foodName", foodName);
        Foods c = query.getSingleResult();
        Integer id = c.getFoodId();
        return String.valueOf(id);
    }
}