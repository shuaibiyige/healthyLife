/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1.service;

import Assignment1.Foods;
import Assignment1.Users;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author lice
 */
@Stateless
@Path("assignment1.users")
public class UsersFacadeREST extends AbstractFacade<Users> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    public UsersFacadeREST() {
        super(Users.class);
    }

    @POST
    @Override
    @Consumes(MediaType.APPLICATION_JSON)
    public void create(Users entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Users entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Users find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces({MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON})
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findByFirstname/{firstname}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByFirstname(@PathParam("firstname") String firstname) {
        Query query = em.createNamedQuery("Users.findByUserFirstname");
        query.setParameter("userFirstname", firstname);
        return query.getResultList();
    }
    
    @GET
    @Path("findBySurname/{Surname}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findBySurname(@PathParam("Surname") String Surname) {
        Query query = em.createNamedQuery("Users.findByUserSurname");
        query.setParameter("userSurname", Surname);
        return query.getResultList();
    }
    
    @GET
    @Path("findByEmail/{Email}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByEmail(@PathParam("Email") String Email) {
        Query query = em.createNamedQuery("Users.findByUserEmail");
        query.setParameter("userEmail", Email);
        return query.getResultList();
    }
    
    @GET
    @Path("findByDOB/{DOB}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByDOB (@PathParam("DOB") String DOB) {
        SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            Date b = a.parse(DOB);
            Query query = em.createNamedQuery("Users.findByUserDob");
            query.setParameter("userDob", b);
            return query.getResultList();
        }
        catch(Exception e)
        {
        }
        return null;
    }
    
    @GET
    @Path("findByHeight/{height}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByHeight (@PathParam("height") Double height) {
        Query query = em.createNamedQuery("Users.findByUserHeight");
        query.setParameter("userHeight", height);
        return query.getResultList();
    }
    
    @GET
    @Path("findByWeight/{weight}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByWeight (@PathParam("weight") Double weight) {
        Query query = em.createNamedQuery("Users.findByUserWeight");
        query.setParameter("userWeight", weight);
        return query.getResultList();
    }
    
    @GET
    @Path("findByGender/{gender}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByGender (@PathParam("gender") String gender) {
        Query query = em.createNamedQuery("Users.findByUserGender");
        query.setParameter("userGender", gender);
        return query.getResultList();
    }
    
    @GET
    @Path("findByAddress/{address}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByAddress (@PathParam("address") String address) {
        Query query = em.createNamedQuery("Users.findByUserAddress");
        query.setParameter("userAddress", address);
        return query.getResultList();
    }
    
    @GET
    @Path("findByPostcode/{postcode}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByPostcode (@PathParam("postcode") Integer postcode) {
        Query query = em.createNamedQuery("Users.findByUserPostcode");
        query.setParameter("userPostcode", postcode);
        return query.getResultList();
    }
    
    @GET
    @Path("findByLevelOfActivity/{levelOfActivity}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByLevelOfActivity (@PathParam("levelOfActivity") Integer levelOfActivity) {
        Query query = em.createNamedQuery("Users.findByLevelOfActivity");
        query.setParameter("levelOfActivity", levelOfActivity);
        return query.getResultList();
    }
    
    @GET
    @Path("findByStepsPerMile/{stepsPerMile}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByStepsPerMile (@PathParam("stepsPerMile") Double stepsPerMile) {
        Query query = em.createNamedQuery("Users.findByStepsPerMile");
        query.setParameter("stepsPerMile", stepsPerMile);
        return query.getResultList();
    }
    
    @GET
    @Path("findByEmailAndUserName/{Email}/{userName}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByEmailAndUserName(@PathParam("Email") String Email, @PathParam("userName") String userName) {
        TypedQuery<Users> query = em.createQuery("SELECT u FROM Users u WHERE u.credentials.userName = :userName AND u.userEmail = :userEmail", Users.class);
        query.setParameter("userEmail", Email);
        query.setParameter("userName", userName);
        return query.getResultList();
    }
    
    @GET
    @Path("findByEmailAndUserName2/{Email}/{userName}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findByEmailAndUserName2(@PathParam("Email") String Email, @PathParam("userName") String userName) {
        Query query = em.createNamedQuery("Users.findByEmailAndUserName2");
        query.setParameter("userEmail", Email);
        query.setParameter("userName", userName);
        return query.getResultList();
    }
    
    @GET
    @Path("caloriesBurnedPerStep/{id}")
    @Produces({MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON})
    public String caloriesBurnedPerStep(@PathParam("id") Integer id)
    {
        Users u = em.find(Users.class, id);
        double weight = u.getUserWeight();
        double stepsPerMile = u.getStepsPerMile();
        double caloriesBurnedPerMile = weight * 0.49;
        double caloriesBurnedPerStep = caloriesBurnedPerMile / stepsPerMile;
        return String.valueOf(caloriesBurnedPerStep);
    }
    
    @GET
    @Path("BMR/{id}")
    @Produces({MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON})
    public String BMR(@PathParam("id") Integer id)
    {
        Users u = em.find(Users.class, id);
        double weightInKg = u.getUserWeight() * 0.45;
        double heightInCm = u.getUserHeight();
        String gender = u.getUserGender();
        Date dob = u.getUserDob();
        Date current = new Date();
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy");
        int currentYear = Integer.valueOf(ft.format(current));
        int dobYear = Integer.valueOf(ft.format(dob));
        int age = currentYear - dobYear;
        if (gender.equals("m"))                     //gender is male
        {
            return String.valueOf((13.75 * weightInKg) + (5.003 * heightInCm) - (6.755 * age) + 66.5);
        }
        else                                        //gender is female
            return String.valueOf((9.563 * weightInKg) + (1.85 * heightInCm) - (4.676 * age) + 655.1);
    }
    
    @GET
    @Path("totalCaloriesBurnedAtRest/{id}")
    @Produces({MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON})
    public String totalCaloriesBurnedAtRest(@PathParam("id") Integer id)
    {
        Users u = em.find(Users.class, id);
        int level = u.getLevelOfActivity();
        double total = 0;
        switch (level)
        {
            case 1: total = Double.valueOf(BMR(id)) * 1.2; break;
            case 2: total = Double.valueOf(BMR(id)) * 1.375; break;
            case 3: total = Double.valueOf(BMR(id)) * 1.55; break;
            case 4: total = Double.valueOf(BMR(id)) * 1.725; break;
            case 5: total = Double.valueOf(BMR(id)) * 1.9; break;
            default: return "error";
        }
        return String.valueOf(total);
    }
    
    @GET
    @Path("findFirstNameByUserName/{userName}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public String findFirstNameByUserName(@PathParam("userName") String userName) {
        TypedQuery<Users> query = em.createQuery("SELECT u FROM Users u WHERE u.credentials.userName = :userName", Users.class);
        query.setParameter("userName", userName);
        return query.getSingleResult().getUserFirstname();
    }
    
    @GET
    @Path("findAddressById/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String findAddressById(@PathParam("id") Integer id) {
        TypedQuery<Users> query = em.createQuery("SELECT u FROM Users u WHERE u.userId = :userId", Users.class);
        query.setParameter("userId", id);
        return query.getSingleResult().getUserAddress();
    }
}
