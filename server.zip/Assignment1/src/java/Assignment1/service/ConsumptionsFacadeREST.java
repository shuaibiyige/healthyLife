/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1.service;

import Assignment1.Consumptions;
import Assignment1.ConsumptionsPK;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.PathSegment;

/**
 *
 * @author lice
 */
@Stateless
@Path("assignment1.consumptions")
public class ConsumptionsFacadeREST extends AbstractFacade<Consumptions> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    private ConsumptionsPK getPrimaryKey(PathSegment pathSegment) {
        /*
         * pathSemgent represents a URI path segment and any associated matrix parameters.
         * URI path part is supposed to be in form of 'somePath;userId=userIdValue;date=dateValue;foodId=foodIdValue'.
         * Here 'somePath' is a result of getPath() method invocation and
         * it is ignored in the following code.
         * Matrix parameters are used as field names to build a primary key instance.
         */
        Assignment1.ConsumptionsPK key = new Assignment1.ConsumptionsPK();
        javax.ws.rs.core.MultivaluedMap<String, String> map = pathSegment.getMatrixParameters();
        java.util.List<String> userId = map.get("userId");
        if (userId != null && !userId.isEmpty()) {
            key.setUserId(new java.lang.Integer(userId.get(0)));
        }
        java.util.List<String> date = map.get("date");
        if (date != null && !date.isEmpty()) {
            key.setDate(new java.util.Date(date.get(0)));
        }
        java.util.List<String> foodId = map.get("foodId");
        if (foodId != null && !foodId.isEmpty()) {
            key.setFoodId(new java.lang.Integer(foodId.get(0)));
        }
        return key;
    }

    public ConsumptionsFacadeREST() {
        super(Consumptions.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Consumptions entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") PathSegment id, Consumptions entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") PathSegment id) {
        Assignment1.ConsumptionsPK key = getPrimaryKey(id);
        super.remove(super.find(key));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Consumptions find(@PathParam("id") PathSegment id) {
        Assignment1.ConsumptionsPK key = getPrimaryKey(id);
        return super.find(key);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Consumptions> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Consumptions> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findByFoodId/{foodId}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Consumptions> findByFoodId (@PathParam("foodId") Integer foodId) {
        Query query = em.createNamedQuery("Consumptions.findByFoodId");
        query.setParameter("foodId", foodId);
        return query.getResultList();
    }
    
    @GET
    @Path("findByQuantity/{quantity}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Consumptions> findByQuantity (@PathParam("quantity") Double quantity) {
        Query query = em.createNamedQuery("Consumptions.findByQuantity");
        query.setParameter("quantity", quantity);
        return query.getResultList();
    }
    
    @GET
    @Path("findByDate/{date}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Consumptions> findByDate (@PathParam("date") String date) {
        SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            Date b = a.parse(date);
            Query query = em.createNamedQuery("Consumptions.findByDate");
            query.setParameter("date", b);
            return query.getResultList();
        }
        catch(Exception e)
        {        
        }
        return null;
    }
    
    @GET
    @Path("totalCaloriesConsumed/{id}/{date}")
    @Produces(MediaType.APPLICATION_JSON)
    public String totalCaloriesConsumed(@PathParam("id") Integer id, @PathParam("date") String date)
    {
        SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            Date b = a.parse(date);
            TypedQuery<Consumptions> query = em.createQuery("SELECT c From Consumptions c WHERE c.consumptionsPK.userId = :userId AND c.consumptionsPK.date = :date", Consumptions.class);
            query.setParameter("userId", id);
            query.setParameter("date", b);
            double calorie;
            double quantity;
            double totalConsumed;
            double count = 0;
            List<Consumptions> c = query.getResultList();
            for (int i = 0; i < c.size(); i++)
            {
                calorie = c.get(i).getFoods().getCalorie();
                quantity = c.get(i).getQuantity();
                totalConsumed = calorie * quantity;
                count = count + totalConsumed;
            }
            return String.valueOf(count);
        }
        catch(Exception e)
        {
        }
        return null;
    }
}
