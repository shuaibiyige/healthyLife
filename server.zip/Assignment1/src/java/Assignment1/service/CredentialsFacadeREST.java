/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1.service;

import Assignment1.Credentials;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author lice
 */
@Stateless
@Path("assignment1.credentials")
public class CredentialsFacadeREST extends AbstractFacade<Credentials> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    public CredentialsFacadeREST() {
        super(Credentials.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Credentials entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Credentials entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Credentials find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces({MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON})
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    
    @GET
    @Path("findByUsername/{username}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> findByUsername (@PathParam("username") String username) {
        Query query = em.createNamedQuery("Credentials.findByUserName");
        query.setParameter("userName", username);
        return query.getResultList();
    }
    
    @GET
    @Path("findByPasswordHash/{passwordHash}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> findByPasswordHash (@PathParam("passwordHash") String passwordHash) {
        Query query = em.createNamedQuery("Credentials.findByPasswordHash");
        query.setParameter("passwordHash", passwordHash);
        return query.getResultList();
    }
    
    @GET
    @Path("findBySignUpDate/{signUpDate}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> findBySignUpDate (@PathParam("signUpDate") String signUpDate) {
        SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            Date b = a.parse(signUpDate);
            Query query = em.createNamedQuery("Credentials.findBySignUpDate");
            query.setParameter("signUpDate", b);
            return query.getResultList();
        }
        catch(Exception e)
        {
        }
        return null;
    }
    
    @GET
    @Path("findPasswordByUserName/{username}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public String findPasswordByUserName (@PathParam("username") String username) 
    {
        TypedQuery<Credentials> query = em.createQuery("SELECT c FROM Credentials c WHERE c.userName = :userName", Credentials.class);
        query.setParameter("userName", username);
        Credentials c = query.getSingleResult();
        String password = c.getPasswordHash();
        return password;
    }
    
    @GET
    @Path("findIdByUserName/{username}")
    @Produces(MediaType.APPLICATION_JSON)
    public String findIdByUserName (@PathParam("username") String username) 
    {
        TypedQuery<Credentials> query = em.createQuery("SELECT c FROM Credentials c WHERE c.userName = :userName", Credentials.class);
        query.setParameter("userName", username);
        Credentials c = query.getSingleResult();
        Integer id = c.getUserId();
        return String.valueOf(id);
    }
}
