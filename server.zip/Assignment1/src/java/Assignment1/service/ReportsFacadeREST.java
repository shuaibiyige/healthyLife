/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1.service;

import Assignment1.GenerateReport;
import Assignment1.Reports;
import Assignment1.ReportsPK;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.PathSegment;

/**
 *
 * @author lice
 */
@Stateless
@Path("assignment1.reports")
public class ReportsFacadeREST extends AbstractFacade<Reports> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    private ReportsPK getPrimaryKey(PathSegment pathSegment) {
        /*
         * pathSemgent represents a URI path segment and any associated matrix parameters.
         * URI path part is supposed to be in form of 'somePath;userId=userIdValue;date=dateValue'.
         * Here 'somePath' is a result of getPath() method invocation and
         * it is ignored in the following code.
         * Matrix parameters are used as field names to build a primary key instance.
         */
        Assignment1.ReportsPK key = new Assignment1.ReportsPK();
        javax.ws.rs.core.MultivaluedMap<String, String> map = pathSegment.getMatrixParameters();
        java.util.List<String> userId = map.get("userId");
        if (userId != null && !userId.isEmpty()) {
            key.setUserId(new java.lang.Integer(userId.get(0)));
        }
        java.util.List<String> date = map.get("date");
        if (date != null && !date.isEmpty()) {
            key.setDate(new java.util.Date(date.get(0)));
        }
        return key;
    }

    public ReportsFacadeREST() {
        super(Reports.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Reports entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") PathSegment id, Reports entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") PathSegment id) {
        Assignment1.ReportsPK key = getPrimaryKey(id);
        super.remove(super.find(key));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Reports find(@PathParam("id") PathSegment id) {
        Assignment1.ReportsPK key = getPrimaryKey(id);
        return super.find(key);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Reports> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Reports> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findByDate/{date}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Reports> findByDate(@PathParam("date") String date) {
        SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            Date b = a.parse(date);
            Query query = em.createNamedQuery("Reports.findByDate");
            query.setParameter("date", b);
            return query.getResultList();
        }
        catch(Exception e)
        {
        }
        return null;
    }
    
    @GET
    @Path("findByCaloriesConsumed/{consumed}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Reports> findByCaloriesConsumed(@PathParam("consumed") Double consumed) {
        Query query = em.createNamedQuery("Reports.findByTotalCaloriesConsumed");
        query.setParameter("totalCaloriesConsumed", consumed);
        return query.getResultList();
    }
    
    @GET
    @Path("findByCaloriesBurned/{burned}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Reports> findByCaloriesBurned(@PathParam("burned") Double burned) {
        Query query = em.createNamedQuery("Reports.findByTotalCaloriesBurned");
        query.setParameter("totalCaloriesBurned", burned);
        return query.getResultList();
    }
    
    @GET
    @Path("findBySteps/{steps}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Reports> findBySteps(@PathParam("steps") Double steps) {
        Query query = em.createNamedQuery("Reports.findByTotalStepsTaken");
        query.setParameter("totalStepsTaken", steps);
        return query.getResultList();
    }
    
    @GET
    @Path("findBygoal/{goal}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Reports> findByGoal(@PathParam("goal") String goal) {
        Query query = em.createNamedQuery("Reports.findByGoal");
        query.setParameter("goal", goal);
        return query.getResultList();
    }
    
    @GET
    @Path("findReport/{id}/{date}")
    @Produces(MediaType.APPLICATION_JSON)
    public String findReport(@PathParam("id") Integer id, @PathParam("date") String date)
    {
        SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            Date b = a.parse(date);
            TypedQuery<Reports> query = em.createQuery("SELECT r FROM Reports r WHERE r.reportsPK.userId = :userId AND r.reportsPK.date = :date", Reports.class);
            query.setParameter("userId", id);
            query.setParameter("date", b);
            Reports c = query.getSingleResult();
            double consumed = c.getTotalCaloriesConsumed();
            double burned = c.getTotalCaloriesBurned();
            double goal = Double.valueOf(c.getGoal());
            String remain = String.valueOf(consumed - burned + goal);
            String result = "total calories consumed: " + consumed + ", " + "total calories burned: " + burned + ", " + "remaining calorie: " + remain;
            return result;
        }
        catch(Exception e)
        {
        }
        return null;
    }
    
    @GET
    @Path("findPeriodReport/{id}/{startingDate}/{endingDate}")
    @Produces(MediaType.APPLICATION_JSON)
    public String findPeriodReport(@PathParam("id") Integer id, @PathParam("startingDate") String startingDate, @PathParam("endingDate") String endingDate)
    {
        SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            Date st = a.parse(startingDate);
            Date en = a.parse(endingDate);
            TypedQuery<Reports> query = em.createQuery("SELECT r FROM Reports r WHERE r.reportsPK.userId = :userId AND r.reportsPK.date BETWEEN :startDate AND :endDate", Reports.class);            
            query.setParameter("userId", id);
            query.setParameter("startDate", st);
            query.setParameter("endDate", en);
            List<Reports> c = query.getResultList();
            double totalConsumed = 0;
            double totalBurned = 0;
            double totalStep = 0;
            for(Reports r: c)
            {
                double consumed = r.getTotalCaloriesConsumed();
                double burned = r.getTotalCaloriesBurned();
                double step = r.getTotalStepsTaken();
                totalConsumed = totalConsumed + consumed;
                totalBurned = totalBurned + burned;
                totalStep = totalStep + step;
            }
            String result = "total calories consumed: " + totalConsumed + ", total calories burned: " + totalBurned + ", total steps: " + totalStep;
            return result;
        }
        catch(Exception e)
        {
        }
        return null;
    }
    
    @GET
    @Path("findPeriodReport2/{id}/{startingDate}/{endingDate}")
    @Produces(MediaType.APPLICATION_JSON)
    public Object findPeriodReport2(@PathParam("id") Integer id, @PathParam("startingDate") String startingDate, @PathParam("endingDate") String endingDate)
    {
        SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            Date st = a.parse(startingDate);
            Date en = a.parse(endingDate);
            TypedQuery<Object[]> query = em.createQuery("SELECT r.totalCaloriesBurned, r.totalCaloriesConsumed FROM Reports r WHERE r.reportsPK.userId = :userId AND r.reportsPK.date BETWEEN :startDate AND :endDate", Object[].class);            
            query.setParameter("userId", id);
            query.setParameter("startDate", st);
            query.setParameter("endDate", en);
            List<Object[]> queryList = query.getResultList();
            JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
            queryList.stream().map((row) -> Json.createObjectBuilder().add("totalCaloriesBurned", (Integer)row[0]).add("totalCaloriesConsumed", (Integer)row[1]).build()).forEachOrdered((personObject) -> {
                arrayBuilder.add(personObject);
            });
            JsonArray jArray = arrayBuilder.build();
            return jArray;
        }
        catch(Exception e)
        {
        }
        return null;
    }
}
