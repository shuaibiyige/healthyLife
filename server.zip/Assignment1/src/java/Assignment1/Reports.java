/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author lice
 */
@Entity
@Table(name = "REPORTS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reports.findAll", query = "SELECT r FROM Reports r")
    , @NamedQuery(name = "Reports.findByUserId", query = "SELECT r FROM Reports r WHERE r.reportsPK.userId = :userId")
    , @NamedQuery(name = "Reports.findByDate", query = "SELECT r FROM Reports r WHERE r.reportsPK.date = :date")
    , @NamedQuery(name = "Reports.findByTotalCaloriesConsumed", query = "SELECT r FROM Reports r WHERE r.totalCaloriesConsumed = :totalCaloriesConsumed")
    , @NamedQuery(name = "Reports.findByTotalCaloriesBurned", query = "SELECT r FROM Reports r WHERE r.totalCaloriesBurned = :totalCaloriesBurned")
    , @NamedQuery(name = "Reports.findByTotalStepsTaken", query = "SELECT r FROM Reports r WHERE r.totalStepsTaken = :totalStepsTaken")
    , @NamedQuery(name = "Reports.findByGoal", query = "SELECT r FROM Reports r WHERE r.goal = :goal")})
public class Reports implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ReportsPK reportsPK;
    @Column(name = "TOTAL_CALORIES_CONSUMED")
    private Integer totalCaloriesConsumed;
    @Column(name = "TOTAL_CALORIES_BURNED")
    private Integer totalCaloriesBurned;
    @Column(name = "TOTAL_STEPS_TAKEN")
    private Integer totalStepsTaken;
    @Size(max = 100)
    @Column(name = "GOAL")
    private String goal;
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Users users;

    public Reports() {
    }

    public Reports(ReportsPK reportsPK) {
        this.reportsPK = reportsPK;
    }

    public Reports(int userId, Date date) {
        this.reportsPK = new ReportsPK(userId, date);
    }

    public ReportsPK getReportsPK() {
        return reportsPK;
    }

    public void setReportsPK(ReportsPK reportsPK) {
        this.reportsPK = reportsPK;
    }

    public Integer getTotalCaloriesConsumed() {
        return totalCaloriesConsumed;
    }

    public void setTotalCaloriesConsumed(Integer totalCaloriesConsumed) {
        this.totalCaloriesConsumed = totalCaloriesConsumed;
    }

    public Integer getTotalCaloriesBurned() {
        return totalCaloriesBurned;
    }

    public void setTotalCaloriesBurned(Integer totalCaloriesBurned) {
        this.totalCaloriesBurned = totalCaloriesBurned;
    }

    public Integer getTotalStepsTaken() {
        return totalStepsTaken;
    }

    public void setTotalStepsTaken(Integer totalStepsTaken) {
        this.totalStepsTaken = totalStepsTaken;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (reportsPK != null ? reportsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reports)) {
            return false;
        }
        Reports other = (Reports) object;
        if ((this.reportsPK == null && other.reportsPK != null) || (this.reportsPK != null && !this.reportsPK.equals(other.reportsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Assignment1.Reports[ reportsPK=" + reportsPK + " ]";
    }
    
}
