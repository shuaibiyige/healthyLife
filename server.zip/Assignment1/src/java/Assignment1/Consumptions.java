/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author lice
 */
@Entity
@Table(name = "CONSUMPTIONS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Consumptions.findAll", query = "SELECT c FROM Consumptions c")
    , @NamedQuery(name = "Consumptions.findByUserId", query = "SELECT c FROM Consumptions c WHERE c.consumptionsPK.userId = :userId")
    , @NamedQuery(name = "Consumptions.findByDate", query = "SELECT c FROM Consumptions c WHERE c.consumptionsPK.date = :date")
    , @NamedQuery(name = "Consumptions.findByFoodId", query = "SELECT c FROM Consumptions c WHERE c.consumptionsPK.foodId = :foodId")
    , @NamedQuery(name = "Consumptions.findByQuantity", query = "SELECT c FROM Consumptions c WHERE c.quantity = :quantity")})
public class Consumptions implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ConsumptionsPK consumptionsPK;
    @Column(name = "QUANTITY")
    private Integer quantity;
    @JoinColumn(name = "FOOD_ID", referencedColumnName = "FOOD_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Foods foods;
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Users users;

    public Consumptions() {
    }

    public Consumptions(ConsumptionsPK consumptionsPK) {
        this.consumptionsPK = consumptionsPK;
    }

    public Consumptions(int userId, Date date, int foodId) {
        this.consumptionsPK = new ConsumptionsPK(userId, date, foodId);
    }

    public ConsumptionsPK getConsumptionsPK() {
        return consumptionsPK;
    }

    public void setConsumptionsPK(ConsumptionsPK consumptionsPK) {
        this.consumptionsPK = consumptionsPK;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Foods getFoods() {
        return foods;
    }

    public void setFoods(Foods foods) {
        this.foods = foods;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (consumptionsPK != null ? consumptionsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Consumptions)) {
            return false;
        }
        Consumptions other = (Consumptions) object;
        if ((this.consumptionsPK == null && other.consumptionsPK != null) || (this.consumptionsPK != null && !this.consumptionsPK.equals(other.consumptionsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Assignment1.Consumptions[ consumptionsPK=" + consumptionsPK + " ]";
    }
    
}
