/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author lice
 */
@XmlRootElement
public class GenerateReport 
{
    private int totalConsumed;
    private int totalBurned;
    
    public GenerateReport()
    {
    }
    
    public GenerateReport(int a, int b)
    {
        totalConsumed = a;
        totalBurned = b;
    }
    
    public void setConsumed(int a)
    {
        totalConsumed = a;
    }
    
    public int getConsumed()
    {
        return totalConsumed;
    }
    
    public void setBurned(int a)
    {
        totalBurned = a;
    }
    
    public int getBurned()
    {
        return totalBurned;
    }
}
